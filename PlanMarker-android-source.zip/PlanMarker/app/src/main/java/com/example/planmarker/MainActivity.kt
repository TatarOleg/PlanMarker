package com.example.planmarker

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

private data class RoomMark(val number: Int, val name: String, val note: String, val l: Float, val t: Float, val r: Float, val b: Float, val color: Long = 0x332563EB)
private data class SavedProject(val name: String, val floor: String, val imagePath: String, val rooms: List<RoomMark>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PlanMarkerApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PlanMarkerApp() {
    val context = LocalContext.current
    var projectName by remember { mutableStateOf("Новый объект") }
    var floorName by remember { mutableStateOf("Этаж 1") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var imagePath by remember { mutableStateOf("") }
    val rooms = remember { mutableStateListOf<RoomMark>() }
    var selected by remember { mutableIntStateOf(-1) }
    var scale by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }
    var drawingStart by remember { mutableStateOf<Offset?>(null) }
    var drawingEnd by remember { mutableStateOf<Offset?>(null) }
    var dragMode by remember { mutableStateOf("draw") }
    var activeDragRoom by remember { mutableIntStateOf(-1) }
    var dialog by remember { mutableStateOf(false) }
    var editingIndex by remember { mutableIntStateOf(-1) }
    var nameInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }
    var projectDialog by remember { mutableStateOf(false) }
    var projectInput by remember { mutableStateOf(projectName) }
    var floorInput by remember { mutableStateOf(floorName) }
    var projects by remember { mutableStateOf(listProjects(context.filesDir)) }
    var showProjects by remember { mutableStateOf(false) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.use { input -> bitmap = BitmapFactory.decodeStream(input) }
            imageUri = uri
            val file = File(context.filesDir, "plan_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(uri)?.use { input -> file.outputStream().use { input.copyTo(it) } }
            imagePath = file.absolutePath
            rooms.clear(); selected = -1; scale = 1f; pan = Offset.Zero
        }
    }

    fun saveProject() {
        val image = bitmap ?: return
        val safe = projectName.ifBlank { "Новый объект" }
        val json = JSONObject().put("name", safe).put("floor", floorName).put("imagePath", imagePath)
        val array = JSONArray()
        rooms.forEach { array.put(JSONObject().put("number", it.number).put("name", it.name).put("note", it.note).put("l", it.l).put("t", it.t).put("r", it.r).put("b", it.b).put("color", it.color)) }
        json.put("rooms", array)
        File(context.filesDir, "project_${(safe + "_" + floorName).hashCode()}.json").writeText(json.toString())
        projects = listProjects(context.filesDir)
    }

    fun exportPdf() {
        val source = bitmap ?: return
        val doc = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(1200, 1600, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas
        val margin = 40f
        val ratio = min((1120f / source.width), (1450f / source.height))
        val w = source.width * ratio; val h = source.height * ratio
        val left = (1200f - w) / 2f; val top = 100f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        canvas.drawText(projectName, margin, 55f, Paint().apply { textSize = 30f; isFakeBoldText = true })
        canvas.drawBitmap(source, null, RectF(left, top, left + w, top + h), p)
        rooms.forEach { room ->
            val rect = RectF(left + room.l * w, top + room.t * h, left + room.r * w, top + room.b * h)
            val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(37, 99, 235); style = Paint.Style.STROKE; strokeWidth = 4f }
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = room.color.toInt(); style = Paint.Style.FILL }
            canvas.drawRect(rect, fill); canvas.drawRect(rect, border)
            val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.rgb(20, 45, 90); textSize = 24f; isFakeBoldText = true }
            canvas.drawText("${room.number}. ${room.name}", rect.left + 5, rect.top + 28, label)
        }
        doc.finishPage(page)
        val out = File(context.getExternalFilesDir(null), "${projectName.replace(" ", "_")}.pdf")
        FileOutputStream(out).use { doc.writeTo(it) }; doc.close()
        android.widget.Toast.makeText(context, "PDF сохранён: ${out.name}", android.widget.Toast.LENGTH_LONG).show()
    }

    Scaffold(topBar = { TopAppBar(title = { Text("PlanMarker", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = { showProjects = true }) { Text("Проекты") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).background(Color(0xFFF4F6FA))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pickImage.launch("image/*") }, modifier = Modifier.weight(1f)) { Text("Загрузить план") }
                OutlinedButton(onClick = { projectInput = projectName; floorInput = floorName; projectDialog = true }) { Text("Объект / этаж") }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { scale = (scale / 1.25f).coerceAtLeast(1f); if (scale == 1f) pan = Offset.Zero }, modifier = Modifier.weight(1f)) { Text("−") }
                OutlinedButton(onClick = { scale = (scale * 1.25f).coerceAtMost(5f) }, modifier = Modifier.weight(1f)) { Text("+") }
                OutlinedButton(onClick = { saveProject(); android.widget.Toast.makeText(context, "Проект сохранён", android.widget.Toast.LENGTH_SHORT).show() }, modifier = Modifier.weight(1f)) { Text("Сохранить") }
                OutlinedButton(onClick = { exportPdf() }, enabled = bitmap != null, modifier = Modifier.weight(1f)) { Text("PDF") }
            }
            Box(Modifier.weight(1f).fillMaxWidth().padding(12.dp).background(Color.White, RoundedCornerShape(12.dp))) {
                val img = bitmap
                if (img == null) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) { Text("Загрузи фотографию плана", color = Color.Gray, fontSize = 18.sp); Text("Затем обводи комнаты прямоугольниками", color = Color.Gray, fontSize = 13.sp) }
                } else {
                    Canvas(Modifier.fillMaxSize()
                        .pointerInput(img, scale, pan) { detectTransformGestures { centroid, panChange, zoom, _ -> scale = (scale * zoom).coerceIn(1f, 5f); pan += panChange } }
                        .pointerInput(img, scale, pan, rooms.size) {
                            detectDragGestures(onDragStart = { p ->
                                drawingStart = p; drawingEnd = p; activeDragRoom = -1; dragMode = "draw"
                                val fit = min(size.width / img.width, size.height / img.height) * scale
                                val iw = img.width * fit; val ih = img.height * fit
                                val ox = (size.width-iw)/2f + pan.x; val oy = (size.height-ih)/2f + pan.y
                                val nx = (p.x-ox)/iw; val ny = (p.y-oy)/ih
                                val hit = rooms.indexOfLast { nx in it.l..it.r && ny in it.t..it.b }
                                if (hit >= 0) {
                                    activeDragRoom = hit; selected = hit
                                    val room = rooms[hit]; val handleX = ox + room.r*iw; val handleY = oy + room.b*ih
                                    dragMode = if (kotlin.math.hypot((p.x-handleX).toDouble(), (p.y-handleY).toDouble()) < 42.0) "resize" else "move"
                                }
                            }, onDrag = { change, _ ->
                                val previous = drawingEnd ?: change.position
                                val delta = change.position - previous
                                drawingEnd = change.position
                                if (activeDragRoom >= 0 && activeDragRoom in rooms.indices) {
                                    val fit = min(size.width / img.width, size.height / img.height) * scale
                                    val dx = delta.x / (img.width*fit); val dy = delta.y / (img.height*fit)
                                    val room = rooms[activeDragRoom]
                                    rooms[activeDragRoom] = if (dragMode == "move") {
                                        val w=room.r-room.l; val h=room.b-room.t; val nl=(room.l+dx).coerceIn(0f,1f-w); val nt=(room.t+dy).coerceIn(0f,1f-h)
                                        room.copy(l=nl,t=nt,r=nl+w,b=nt+h)
                                    } else room.copy(r=(room.r+dx).coerceIn(room.l+0.01f,1f), b=(room.b+dy).coerceIn(room.t+0.01f,1f))
                                }
                            }, onDragEnd = {
                                val a = drawingStart; val b = drawingEnd
                                if (dragMode == "draw" && activeDragRoom < 0 && a != null && b != null && kotlin.math.abs(a.x-b.x) > 12 && kotlin.math.abs(a.y-b.y) > 12) {
                                    val fit = min(size.width / img.width, size.height / img.height) * scale
                                    val iw = img.width * fit; val ih = img.height * fit
                                    val ox = (size.width-iw)/2f + pan.x; val oy = (size.height-ih)/2f + pan.y
                                    val x1 = ((min(a.x,b.x)-ox)/iw).coerceIn(0f,1f); val x2 = ((max(a.x,b.x)-ox)/iw).coerceIn(0f,1f)
                                    val y1 = ((min(a.y,b.y)-oy)/ih).coerceIn(0f,1f); val y2 = ((max(a.y,b.y)-oy)/ih).coerceIn(0f,1f)
                                    editingIndex = -1; nameInput = ""; noteInput = ""; pendingRect = RoomMark(rooms.size+1, "Комната ${rooms.size+1}", "", x1,y1,x2,y2); dialog = true
                                }
                                drawingStart = null; drawingEnd = null; activeDragRoom = -1; dragMode = "draw"
                            })
                        }
                        .pointerInput(img, scale, pan, rooms.size) { detectTapGestures { tap ->
                            val fit = min(size.width / img.width, size.height / img.height) * scale; val iw=img.width*fit; val ih=img.height*fit; val ox=(size.width-iw)/2f+pan.x; val oy=(size.height-ih)/2f+pan.y
                            val nx=(tap.x-ox)/iw; val ny=(tap.y-oy)/ih
                            val idx=rooms.indexOfLast { nx in it.l..it.r && ny in it.t..it.b }
                            if (idx >= 0) { selected=idx; editingIndex=idx; nameInput=rooms[idx].name; noteInput=rooms[idx].note; dialog=true }
                        } }
                    ) {
                        val fit = min(size.width / img.width, size.height / img.height) * scale
                        val iw = img.width * fit; val ih = img.height * fit
                        val ox = (size.width - iw) / 2f + pan.x; val oy = (size.height - ih) / 2f + pan.y
                        drawImage(img.asImageBitmap(), dstOffset = IntOffset(ox.toInt(), oy.toInt()), dstSize = IntSize(iw.toInt(), ih.toInt()))
                        rooms.forEachIndexed { i, room ->
                            val l=ox+room.l*iw; val t=oy+room.t*ih; val r=ox+room.r*iw; val b=oy+room.b*ih
                            drawRect(Color(room.color), Offset(l,t), Size(r-l,b-t)); drawRect(if(i==selected) Color(0xFFFF8A00) else Color(0xFF2563EB), Offset(l,t), Size(r-l,b-t), style=Stroke(if(i==selected) 5f else 3f))
                            drawContext.canvas.nativeCanvas.drawText("${room.number}. ${room.name}", l+5, t+22, android.graphics.Paint().apply { color=android.graphics.Color.rgb(20,45,90); textSize=18f; isFakeBoldText=true })
                        }
                        val a=drawingStart; val b=drawingEnd
                        if(a!=null && b!=null) drawRect(Color(0xFF16A34A), Offset(min(a.x,b.x),min(a.y,b.y)), Size(kotlin.math.abs(a.x-b.x),kotlin.math.abs(a.y-b.y)), style=Stroke(3f))
                    }
                }
            }
            Text("Комнаты: ${rooms.size}  •  Нажми на комнату, чтобы изменить название или заметку", Modifier.padding(horizontal=16.dp, vertical=4.dp), color=Color.DarkGray, fontSize=12.sp)
            LazyColumn(Modifier.heightIn(max=150.dp).padding(horizontal=12.dp)) {
                itemsIndexed(rooms) { index, room -> Card(Modifier.fillMaxWidth().padding(vertical=3.dp), onClick = { selected=index; editingIndex=index; nameInput=room.name; noteInput=room.note; dialog=true }) { Row(Modifier.padding(10.dp), verticalAlignment=Alignment.CenterVertically) { Text("${room.number}.", fontWeight=FontWeight.Bold); Spacer(Modifier.width(8.dp)); Column { Text(room.name); if(room.note.isNotBlank()) Text(room.note, fontSize=11.sp, color=Color.Gray) } } } }
            }
        }
    }

    if (dialog) AlertDialog(onDismissRequest = { dialog=false }, title = { Text(if(editingIndex<0) "Новая комната" else "Комната ${editingIndex+1}") }, text = { Column { OutlinedTextField(nameInput, { nameInput=it }, label={Text("Название")}); Spacer(Modifier.height(8.dp)); OutlinedTextField(noteInput, { noteInput=it }, label={Text("Заметка")}); Spacer(Modifier.height(8.dp)); Text("Цвет комнаты"); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf(0x332563EB,0x3338A169,0x33D97706,0x33DC2626,0x338B5CF6).forEach { c -> Surface(Modifier.size(32.dp), color=Color(c.toLong()), shape=RoundedCornerShape(6.dp), onClick={ if(editingIndex>=0 && editingIndex in rooms.indices) rooms[editingIndex]=rooms[editingIndex].copy(color=c.toLong()) else pendingRect=pendingRect?.copy(color=c.toLong()) }) {} } } } }, confirmButton = { TextButton(onClick = { if(editingIndex<0) { val p=pendingRect; if(p!=null) rooms.add(p.copy(name=nameInput.ifBlank { p.name }, note=noteInput)) } else if(editingIndex in rooms.indices) rooms[editingIndex]=rooms[editingIndex].copy(name=nameInput, note=noteInput); dialog=false }) { Text("Готово") } }, dismissButton = { Row { if(editingIndex>=0) TextButton(onClick={ if(editingIndex in rooms.indices) rooms.removeAt(editingIndex); dialog=false }) { Text("Удалить") }; TextButton(onClick={dialog=false}) { Text("Отмена") } } } })
    if(projectDialog) AlertDialog(onDismissRequest={projectDialog=false}, title={Text("Название объекта")}, text={Column { OutlinedTextField(projectInput,{projectInput=it},label={Text("Название объекта")}); OutlinedTextField(floorInput,{floorInput=it},label={Text("Название этажа")}) }}, confirmButton={TextButton(onClick={projectName=projectInput;floorName=floorInput.ifBlank { "Этаж 1" };projectDialog=false}){Text("Сохранить")}})
    if(showProjects) AlertDialog(onDismissRequest={showProjects=false}, title={Text("Сохранённые проекты")}, text={ Column { if(projects.isEmpty()) Text("Пока нет сохранённых проектов") else projects.forEach { p -> TextButton(onClick={ projectName=p.name; floorName=p.floor; imagePath=p.imagePath; bitmap=BitmapFactory.decodeFile(p.imagePath); rooms.clear(); rooms.addAll(p.rooms); showProjects=false }) { Text("${p.name} — ${p.floor}") } } } }, confirmButton={TextButton(onClick={showProjects=false}){Text("Закрыть")}})
}

private var pendingRect: RoomMark? = null

private fun listProjects(dir: File): List<SavedProject> = dir.listFiles { f -> f.name.startsWith("project_") && f.extension=="json" }?.mapNotNull { file ->
    runCatching { val j=JSONObject(file.readText()); val arr=j.getJSONArray("rooms"); val rs=(0 until arr.length()).map { i -> val r=arr.getJSONObject(i); RoomMark(r.getInt("number"),r.getString("name"),r.optString("note"),r.getDouble("l").toFloat(),r.getDouble("t").toFloat(),r.getDouble("r").toFloat(),r.getDouble("b").toFloat(),r.optLong("color", 0x332563EB)) }; SavedProject(j.getString("name"),j.optString("floor", "Этаж 1"),j.getString("imagePath"),rs) }.getOrNull()
} ?: emptyList()
